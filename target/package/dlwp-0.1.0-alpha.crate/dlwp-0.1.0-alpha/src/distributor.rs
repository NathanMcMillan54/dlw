pub const USER_INIT: &str = "INIT-USR";
pub const DIST_INIT: &str = "INIT-DIS";
pub const INSTANCE_INIT: &str = "INIT-INST";
pub const DISCONNECT: &str = "DISCC";
pub const GET_DISTRIBUTOR: &str = "GET-DIS";
pub const READ_AVAILABLE: &str = "SSS";
pub const MSG_INIT: &str = "\\z ";
pub const MSG_END: &str = " \\q";
